# Da Echo「眼镜 AI → 手机 App 操控」模块设计（v1）

> 目标：让用户通过眼镜（语音/按键/触摸）指挥 Da Echo，进而操控手机上任意第三方 App。
> 形态：App 工程源码内新增能力，不改动 APK 重打包、不需要 root。执行层**双轨**：
> - **产品态（眼镜日常使用）**：无障碍服务为主执行器，无 adb 依赖；
> - **开发/调试/自动化态（adb 生态）**：电脑经 adb 操控同一套操作语言，见 **§8**。

---

## 1. 总体架构

```
眼镜 M08E (RTOS, 主控 MOY-A113)
   │  语音上行(Opus) / 按键 / 触摸 / AI对话意图(下行指令已存在)
   │  BLE GATT（现有 base.ble.cmd 通道）
   ▼
Da Echo App（手机侧，新增 AppControl 模块）
   ├─ ① 语音链路: ASR(已有) → LLM(已有) → LLMCommandParser(已有)
   ├─ ② 【新增】AppControlCommandType / AppIntentParser
   │     识别 "打开微信" / "给张三发消息" / "点一下搜索" 等意图
   ├─ ③ 【新增】执行层:
   │     ├─ AccessibilityEngine  (无障碍服务，主执行器)
   │     ├─ UiNodeFinder        (查找目标节点 text/desc/id)
   │     ├─ UiActionExecutor    (click/longClick/scroll/input/back)
   │     └─ ScreenStateReader    (读取当前界面节点树→转结构化文本给LLM)
   └─ ④ 【新增】ResultFeedback   (执行结果→TTS播报回眼镜 / BLE状态上报)
```

> 电脑调试侧（开发态）：PC ⇄ adb（USB/无线）⇄ 手机，复用下方同一套操作语言 —— 详见 §8。

数据流（一个完整闭环）：
```
用户说: "帮我打开微信"
  → 眼镜麦克风 → BLE音频 → ASR文本 → LLM(带系统能力提示词)
  → LLM 返回结构化命令 {type: APP_CONTROL, app: 微信}
  → AppIntentParser 解析出目标动作
  → AccessibilityEngine: am-like 打开微信(launch Intent / 点桌面图标兜底)
  → ScreenStateReader 读取微信界面 → 文本化
  → (可选) 二次LLM决策下一步 → UiActionExecutor 执行
  → TTS: "已为你打开微信"
```

---

## 2. 需要新增的源码模块清单

```
app/src/main/java/com/moyoung/glasses/appcontrol/
├── AppControlManager.kt            # 模块总入口(单例), 绑定BLE指令+AI意图
├── intent/
│   ├── AppControlIntent.kt         # 意图数据模型(打开App/点击/输入/返回/滚动/截图)
│   └── AppIntentParser.kt          # LLM输出 → AppControlIntent
├── engine/
│   ├── AccessibilityEngineService.kt   # 无障碍服务(核心执行器)
│   ├── UiNodeFinder.kt             # 按 text/desc/resource-id 找可执行节点
│   ├── UiActionExecutor.kt         # 执行 click/longClick/scroll/back/inputText
│   ├── ScreenStateReader.kt        # 把当前 UI 树压缩成 LLM 可读文本
│   └── AppLauncher.kt              # 启动任意App(Intent + 桌面搜索兜底)
├── feedback/
│   └── ExecutionFeedback.kt        # 结果→TTS / BLE 上报(复用已有TTS)
└── ble/
    └── AppControlBleCommand.kt     # 扩展BLE协议: 眼镜端"打开XXApp"入口命令
```

对应要改的**现有文件/位置**（按之前逆向结论标注）：
| 现有位置 | 改动 |
|---|---|
| `com.moyoung.base.ble.cmd.*` | 新增一条 `CMD_APP_CONTROL` 自定义命令类型（走已有 CMD_CUSTOM 框架）|
| `com.moyoung.glasses.ai.llm.LLMCommandType` | 增加枚举值 `APP_OPEN / APP_CLICK / APP_INPUT / APP_BACK / APP_SCROLL / APP_QUERY_SCREEN` |
| `com.moyoung.glasses.ai.llm.LLMCommandParser` | 增加对应解析分支 → 产出 AppControlIntent |
| `com.moyoung.glasses.ai.AiDeviceCommandSender` | 兼容：眼镜发来的"控制手机"意图进入 AppControlManager |
| `AndroidManifest.xml` | 注册 AccessibilityEngineService + 权限 |
| `res/xml/accessibility_service_config.xml` | 无障碍服务配置(canPerformGestures 等) |

> 配套**开发态脚本库**（不进 APK，仓库 `tools/adb_ecosystem/`，当前位于 `/workspace/scripts/adb_ecosystem/`）：
> 让同一套 UiOperation 在电脑上也能跑（读屏/点击/输入/启 App），用于快速原型与自动化回归，见 §8。

---

## 3. 无障碍服务核心骨架（Kotlin）

```kotlin
// AccessibilityEngineService.kt —— 主执行器
package com.moyoung.glasses.appcontrol.engine

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AccessibilityEngineService : AccessibilityService() {

    companion object {
        @Volatile var instance: AccessibilityEngineService? = null
            private set
        const val ACTION_EXEC = "com.moyoung.glasses.appcontrol.EXEC"
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* 可按需监听窗口变化 */ }

    override fun onInterrupt() {}

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    // ---------- 执行入口 ----------
    fun clickNode(node: AccessibilityNodeInfo): Boolean {
        return node.performAction(AccessibilityNodeInfo.ACTION_CLICK) ||
               node.performAction(AccessibilityNodeInfo.ACTION_PRESS)
    }

    fun inputText(node: AccessibilityNodeInfo, text: String): Boolean {
        if (!node.performAction(AccessibilityNodeInfo.ACTION_FOCUS)) return false
        val bundle = android.os.Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        return node.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, bundle)
    }

    /** 模拟点击屏幕坐标(用于没有节点可点的图形区) */
    fun tap(x: Int, y: Int): Boolean {
        val path = Path().apply { moveTo(x.toFloat(), y.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 80))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun swipe(x1: Int, y1: Int, x2: Int, y2: Int, dur: Long = 300): Boolean {
        val path = Path().apply { moveTo(x1.toFloat(), y1.toFloat()); lineTo(x2.toFloat(), y2.toFloat()) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, dur))
            .build()
        return dispatchGesture(gesture, null, null)
    }

    fun globalBack() = performGlobalAction(GLOBAL_ACTION_BACK)
    fun globalHome() = performGlobalAction(GLOBAL_ACTION_HOME)
    fun globalRecents() = performGlobalAction(GLOBAL_ACTION_RECENTS)
}
```

```kotlin
// UiNodeFinder.kt —— 按语义找节点
package com.moyoung.glasses.appcontrol.engine

import android.view.accessibility.AccessibilityNodeInfo

object UiNodeFinder {
    /** 按 text/desc/资源id 找可点击节点；支持包含匹配 */
    fun findByText(root: AccessibilityNodeInfo?, target: String, clickable: Boolean = true): AccessibilityNodeInfo? {
        root ?: return null
        if (root.text?.toString()?.contains(target, true) == true ||
            root.contentDescription?.toString()?.contains(target, true) == true) {
            var n = root
            if (clickable && !n.isClickable) {
                var p = n.parent
                while (p != null) {
                    if (p.isClickable) { n = p; break }
                    p = p.parent
                }
            }
            return n
        }
        for (i in 0 until root.childCount) {
            findByText(root.getChild(i), target, clickable)?.let { return it }
        }
        return null
    }
}
```

```kotlin
// ScreenStateReader.kt —— 把界面转成 LLM 能"看懂"的文本
package com.moyoung.glasses.appcontrol.engine

import android.view.accessibility.AccessibilityNodeInfo

object ScreenStateReader {
    data class UiLine(val role: String, val text: String, val bounds: String, val clickable: Boolean, val node: AccessibilityNodeInfo)

    fun snapshot(root: AccessibilityNodeInfo?, max: Int = 120): String {
        val lines = mutableListOf<String>()
        fun walk(n: AccessibilityNodeInfo?, depth: Int) {
            n ?: return
            if (depth > 12 || lines.size >= max) return
            val t = n.text?.toString()?.trim()
            val d = n.contentDescription?.toString()?.trim()
            val label = t ?: d
            if (!label.isNullOrBlank()) {
                val bounds = n.boundsInScreen
                lines += "${"  ".repeat(depth)}[${if (n.isClickable) "可点" else "文本"}] $label (${bounds.left},${bounds.top})")
            }
            for (i in 0 until n.childCount) walk(n.getChild(i), depth + 1)
        }
        walk(root, 0)
        return lines.joinToString("\n")
    }
}
```

---

## 4. BLE 命令扩展（眼镜入口）

在现有 `LogicalCommandId` / CMD_CUSTOM 体系内新增一类即可，方向：**眼镜 → 手机**

```kotlin
// AppControlBleCommand.kt（示意：解析眼镜发来的"控制手机"意图）
enum class AppControlCmd(val id: Int) {
    APP_OPEN(0x51),      // 打开指定App, 参数: app包名/别名
    APP_QUERY_SCREEN(0x52), // 读取当前屏幕(文本)回传眼镜
    APP_TAP(0x53),       // 坐标点击 / 语义点击
    APP_INPUT(0x54),     // 输入文字
    APP_BACK(0x55),      // 返回
    APP_HOME(0x56),      // 回桌面
    APP_SCROLL(0x57),    // 滚动
}
```
（接入处：复用 `com.moyoung.base.ble.cmd.Command` 的分发逻辑；新命令在手机端转成
`AccessibilityEngineService` 调用，无需给眼镜升级固件 —— 眼镜只需发指令字节。）

---

## 5. 授权/引导流程（无障碍开启体验设计）

1. App 内"AI 操控手机"开关 → 检测 `AccessibilityEngineService` 是否启用
2. 未启用 → 弹引导页（说明用途/隐私），按钮跳 `Settings.ACTION_ACCESSIBILITY_SETTINGS`
3. 用户开启后回跳 → 自检通过 → 提示"眼镜 AI 操控已就绪"，可语音测试
4. 隐私设计：操控记录仅本地、可一键关闭、敏感界面(密码/支付)默认跳过
   - 检测 `FLAG_SECURE` / `isPassword` 节点 → 拒绝执行并提示

---

## 6. LLM 侧接入（让 AI 会"使用手机"）

提示词中追加"你可以操作手机App"的能力声明，要求 LLM 输出结构化意图而非自然语言：

```json
{"type":"APP_CONTROL","intent":"OPEN_APP","app":"微信"}
{"type":"APP_CONTROL","intent":"CLICK","target":"搜索","window":"微信"}
{"type":"APP_CONTROL","intent":"INPUT","text":"给XX发消息"}
{"type":"APP_CONTROL","intent":"SCREENSHOT_DESCRIBE"}   // 先读屏再决策
```

执行循环（多步）：
```
LLM(当前屏幕文本 + 用户目标) → 下一步意图 → 执行 → 重新读屏 → LLM...直到完成
```

---

## 7. 里程碑拆分

| 阶段 | 内容 | 产出 |
|---|---|---|
| M0 | adb 生态脚手架：UiOperation 统一模型 + 脚本库(读屏/启App/点击/输入/流程) | 电脑 adb 可操控任意 App，为 M1+ 提供调试与回归通道 |
| M1 | 无障碍服务 + 读屏/找节点/点击/输入/返回 | "打开微信+点击搜索" 跑通 |
| M2 | LLM 意图解析 + 提示词 + 多步循环 | "语音说→自动完成简单任务" |
| M3 | BLE 眼镜入口 + TTS反馈 + 隐私/降级 | 眼镜端可用 |
| M4 | 异常恢复/超时/黑名单/测试 | 可内测 |
| M5 | adb 自动化回归 + LLM 多步循环(adb 后端)演练 | 全链路(眼镜→手机)可内测 |

---

## 8. adb 生态：开发/调试/自动化执行后端

> 一句话：**无障碍 = 产品态（眼镜日常用）；adb = 开发态（电脑调试、回归、AI 流程演练）。**
> 两者共享一套 UiOperation 操作语言：App 内翻译成无障碍 API，电脑上翻译成 adb 命令，
> 验证通过的流程可直接固化成 App 内无障碍实现。

### 8.1 架构

```
PC / 开发机（M0 之后随时可用）
  ├─ scripts/adb_ecosystem/*.sh   ← 本仓库 tools/ 同步
  │     op.sh / screen.sh / flow.sh / pkg.sh / 01_connect.sh
  └─ adb (USB 或 无线调试, Android 11+)
        │  UiOperation 语言（JSON/文本指令）
        ▼
手机（Da Echo 设备, MIUI, 无 root）
  ├─ uiautomator dump      → 读屏文本化（= ScreenStateReader 的 adb 版）
  ├─ input tap/swipe/text  → 手势/输入（= UiActionExecutor 的 adb 版）
  ├─ am start / monkey     → 打开 App（= AppLauncher 的 adb 版）
  └─ exec-out screencap    → 截图存档
```

### 8.2 UiOperation 统一语言（双后端都吃这一套）

```json
{"op":"OPEN_APP","app":"微信"}
{"op":"TAP","x":540,"y":1200}
{"op":"CLICK_TEXT","target":"搜索","window":"微信"}
{"op":"INPUT","text":"你好"}
{"op":"SWIPE","from":[540,1600],"to":[540,800],"ms":300}
{"op":"BACK"} / {"op":"HOME"} / {"op":"RECENTS"}
{"op":"SCREEN_TEXT"}   // 读屏
{"op":"SCREENSHOT"}    // 截图
```

- App 内：`AppIntentParser` 解析 → `AccessibilityEngineService` 执行；
- PC 端：`op.sh`（单步）与 `flow.sh`（多步流程文件）逐条翻译为 adb 命令。
  流程文件即「可执行的测试用例/演示剧本」，可纳入回归。

### 8.3 命令映射表

| UiOperation | App 内无障碍实现 | adb 脚本命令 |
|---|---|---|
| OPEN_APP | AppLauncher(Intent) | `op.sh open 微信`（别名→包名→am start，失败 monkey 兜底） |
| TAP 坐标 | dispatchGesture | `op.sh tap x y` |
| CLICK_TEXT | UiNodeFinder + ACTION_CLICK | `screen.sh --text` 看坐标 → `tap`（半自动） |
| INPUT 文本 | ACTION_SET_TEXT | `op.sh text`（ASCII，空格写 %s） |
| INPUT 中文 | ACTION_SET_TEXT | `op.sh adbk 中文`（ADBKeyboard 广播） |
| SWIPE/滚动 | dispatchGesture | `op.sh swipe x1 y1 x2 y2 [ms]` |
| BACK/HOME/多任务 | GLOBAL_ACTION_* | `op.sh back / home / recents` / `op.sh key BACK` |
| 读屏文本化 | ScreenStateReader | `op.sh dump`（=`screen.sh --text`） |
| 截图 | MediaProjection(产品态) | `op.sh shot`（exec-out screencap） |
| 包名解析 | — | `pkg.sh -n 微信 / -s 关键字`（离线包清单或在线 pm） |
| 无线连接 | — | `01_connect.sh pair/connect` |

### 8.4 脚本库（本工作区 /workspace/scripts/adb_ecosystem/）

```
├── README.md          # 快速开始 + 映射表 + 常见坑
├── 00_env.sh          # 公共环境: adb 定位/设备选择/source
├── 01_connect.sh      # 无线调试: pair <ip:端口> <码> / connect <ip:端口>
├── pkg.sh             # 中文别名→包名; -n 精确 / -s 模糊 / -a 别名表
├── screen.sh          # --xml 原始UI树 / --text 文本快照[可点]文案(x,y)
├── op.sh              # 单步: open/tap/text/adbk/swipe/key/dump/shot/sleep
├── flow.sh            # 多步: flow.sh <file.flow>，逐行执行 op.sh
└── examples/*.flow    # 演示: 打开QQ→读屏→截图→回桌面
```

### 8.5 典型用法（开发工作流）

1. **快速原型**：`op.sh open QQ && op.sh dump` 拿当前界面文本/坐标，
   验证「点哪里、输入什么」——与眼镜 AI 流程完全同构。
2. **AI 多步循环演练（M5）**：LLM 决策 → 翻译成 flow 文件 → `flow.sh` 实跑 →
   截图/dump 校验 → 回灌给 LLM 决策下一步，直到任务完成。
3. **回归测试**：每轮改动跑一遍 `examples/*.flow` + 截图比对。
4. **无障碍对照调优**：adb 跑通的坐标/文案，用来校准 `UiNodeFinder` 的语义匹配与兜底坐标。

### 8.6 已知限制与对策（写入代码注释/文档）

| 限制 | 对策 |
|---|---|
| `input text` 不支持中文 | 安装 ADBKeyboard.apk 并设为输入法，走 `op.sh adbk` 广播输入 |
| uiautomator dump 需界面空闲 | 动画中会报 idle 错，先 `sleep 1~2` 重试（screen.sh 已内置双路径重试） |
| MIUI 后台启动限制 | `op.sh open` 先 am start，失败回落 monkey（已内置） |
| 截图 \r\n 破坏 PNG | 必须 `adb exec-out screencap -p`（已内置） |
| shell 特殊字符注入 | 文本参数一律单引号包裹 + 空格转 %s（已内置） |
| 无线调试需 Android 11+ | 旧设备走 USB 线即可；`01_connect.sh` 提供无线通道 |

