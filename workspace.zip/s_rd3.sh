cat /root/autodl-tmp/_o_rd2.txt 2>/dev/null | head -40
