cd /root/autodl-tmp
R=/root/autodl-tmp/_x.txt
rm -f $R
for d in /root/distill_calc_v1 /root/distill_chain_v1 /root/distill_top_v1 /root/distill_v4c /root/distill_v5 /root/autodl-tmp/life1/v58_logic_05b; do
  echo "===== $d =====" >> $R
  du -sh $d 2>/dev/null >> $R
  ls $d 2>/dev/null | head -6 >> $R
  head -c 400 $d/config.json 2>/dev/null >> $R
  echo "" >> $R
done
echo "" >> $R
echo "===== distill_calc 的训练脚本 =====" >> $R
ls /root/*distill*calc* /root/*calc*train* 2>/dev/null >> $R
echo "X_DONE" >> $R
