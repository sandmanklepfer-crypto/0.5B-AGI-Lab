#!/bin/bash
cd /root/autodl-tmp/life1
ls -la _bridge2.py > run.log 2>&1
nohup /root/miniconda3/bin/python3 -u _bridge2.py >> run.log 2>&1 &
echo PID=$! >> run.log
