cd /root/autodl-tmp
E=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
M=/root/autodl-tmp/qwen05b_q4km.gguf
CV=/root/autodl-tmp/control_reason.gguf
P=$(printf "<|im_start|>user\\n12 + 34 = ?<|im_end|>\\n<|im_start|>assistant\\n")
export LC_ALL=C.UTF-8
$E -m $M -p "$P" -n 40 --temp 0.2 -ngl 99 --no-warmup -no-cnv --log-disable --control-vector-scaled $CV:2.0 --control-vector-layer-range 0 23 > /root/autodl-tmp/_raw.txt 2>&1
echo RAW_DONE >> /root/autodl-tmp/_raw.txt
