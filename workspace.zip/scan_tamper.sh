#!/bin/bash
export ADB=/usr/bin/adb
$ADB start-server >/dev/null 2>&1
dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
if [ -z "$dev" ]; then
  $ADB connect 127.0.0.1:5555 >/dev/null 2>&1
  $ADB -s emulator-5554 reconnect >/dev/null 2>&1
  sleep 1
  dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
fi
[ -z "$dev" ] && { echo "NO_DEVICE"; exit 1; }
S(){ timeout 20 $ADB -s "$dev" shell "$@"; }
echo "########## DEVICE: $dev"
echo "===== [1] build / security props ====="
S 'getprop | grep -Ei "ro.build.type|ro.debuggable|ro.secure|ro.adb.secure|ro.build.tags|ro.build.version.security_patch|ro.build.date"'
echo "===== [2] suspicious props ====="
S 'getprop | grep -Ei "magisk|zygisk|lsposed|xposed|riru|persist.sys.recovery|ro.boot.verifiedbootstate|ro.boot.flash.locked|ro.boot.warranty"'
echo "===== [3] battery override ====="
S 'dumpsys battery' | head -40
echo "===== [4] su / magisk ====="
S 'which su magisk busybox 2>/dev/null; ls -l /system/bin/su /system/xbin/su /sbin/su /data/adb 2>/dev/null; echo "--done--"'
echo "===== [5] mounts ====="
S 'mount | grep -Ei " /system| /vendor| /data "'
echo "===== [6] third-party packages ====="
S 'pm list packages -3 -f | sort'
echo "===== [7] recent installs ====="
S 'ls -lt /data/app/ 2>/dev/null | head -20'
