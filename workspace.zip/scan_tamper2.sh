#!/bin/bash
export ADB=/usr/bin/adb
$ADB start-server >/dev/null 2>&1
dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
[ -z "$dev" ] && { $ADB connect 127.0.0.1:5555 >/dev/null 2>&1; sleep 1; dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}'); }
[ -z "$dev" ] && { echo "NO_DEVICE"; exit 1; }
S(){ timeout 25 $ADB -s "$dev" shell "$@"; }
echo "########## DEVICE: $dev"
echo "===== [A] SELinux / 内核 ====="
S 'getenforce; uname -a'
echo "===== [B] 电池上报是否有 override ====="
S 'dumpsys battery | grep -Ei "Override|Test|Counter|Charging state"' 
echo "===== [C] 无障碍服务 (可看屏幕/代点) ====="
S 'settings get secure enabled_accessibility_services; settings get secure accessibility_enabled'
echo "===== [D] 通知监听 (可读全部通知) ====="
S 'settings get secure enabled_notification_listeners'
echo "===== [E] 设备管理器 / DeviceOwner ====="
S 'dumpsys device_policy | grep -Ei "Device Owner|Profile Owner|admin=|isAdmin" | head -20'
echo "===== [F] VPN / AlwaysOn ====="
S 'settings get secure always_on_vpn_app; dumpsys connectivity | grep -i "VPN" | head -5'
echo "===== [G] 输入法 / 桌面 (被换过?) ====="
S 'settings get secure default_input_method; cmd package resolve-activity -c android.intent.category.HOME -a android.intent.action.MAIN 2>/dev/null | tail -3'
echo "===== [H] 哪个进程在吃 CPU (宿主 load 高) ====="
S 'top -b -n 1 -o %CPU,ARGS 2>/dev/null | head -22'
echo "===== [I] 僵死进程 ====="
S 'ps -A -o PID,PPID,STAT,ARGS 2>/dev/null | awk "\$3 ~ /Z/" | head'
echo "===== [J] /data/local/tmp ====="
S 'ls -la /data/local/tmp 2>/dev/null'
echo "===== [K] adb 无线调试是否常开 ====="
S 'getprop service.adb.tcp.port; getprop persist.adb.tcp.port; settings get global adb_wifi_enabled'
