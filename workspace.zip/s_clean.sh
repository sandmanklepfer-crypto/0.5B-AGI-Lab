cd /root/autodl-tmp
# 删掉重复的大模型 (保留 calc_v1 / un_neg150 / q4km)
rm -f qwen05b_fp16.gguf calc_v1_un5.gguf 2>/dev/null
rm -f un_pos150.gguf 2>/dev/null
df -h / | tail -1
ls -la *.gguf | awk '{print $5, $9}'
