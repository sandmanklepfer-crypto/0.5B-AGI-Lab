cd /root/autodl-tmp
/root/miniconda3/bin/python s_p1.py > _p1.txt 2>&1
echo DONE >> _p1.txt
