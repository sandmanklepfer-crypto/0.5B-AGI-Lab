R=/root/autodl-tmp/_DR.txt
rm -f $R
echo "=== l23 里的关键文件 ===" >> $R
ls -la /root/autodl-tmp/l23/ | grep -vE "all__L[0-9]+\.bin" | head -25 >> $R
echo "" >> $R
echo "=== d_refusal.bin 详情 ===" >> $R
/root/miniconda3/bin/python -c "
import numpy as np,os
p='/root/autodl-tmp/l23/d_refusal.bin'
print(' size',os.path.getsize(p),'bytes')
d=np.fromfile(p,np.float32)
print(' shape',d.shape,' norm',float(np.linalg.norm(d)),' max',float(np.abs(d).max()),' mean',float(d.mean()))
print(' 前8值',d[:8])
" >> $R 2>&1
echo "" >> $R
echo "=== unlock_pipe.log 最后30行 ===" >> $R
tail -30 /root/autodl-tmp/unlock_pipe.log >> $R 2>&1
echo "DR_DONE" >> $R
