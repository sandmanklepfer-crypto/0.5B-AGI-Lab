# -*- coding: utf-8 -*-
import numpy as np, itertools
np.set_printoptions(precision=4, suppress=True)

print("=== 1 三对角行列式 D_n=|2 -1; -1 2 -1; ...| 应等于 n+1 ===")
for n in range(1,7):
    M=np.diag([2]*n)+np.diag([-1]*(n-1),1)+np.diag([-1]*(n-1),-1)
    print(f"  n={n}: det={np.linalg.det(M):.6f}   n+1={n+1}")

print("\n=== 2 范德蒙德 |1 1 1; a b c; a² b² c²| = (b-a)(c-a)(c-b) ===")
for (a,b,c) in [(1,2,4),(0,1,3),(2,5,7)]:
    V=np.array([[1,1,1],[a,b,c],[a*a,b*b,c*c]],dtype=float)
    print(f"  a,b,c={a},{b},{c}: det={np.linalg.det(V):.6f}  公式={(b-a)*(c-a)*(c-b)}")

print("\n=== 3 |a b b...; b a b...| n阶 = (a-b)^(n-1)·(a+(n-1)b) ===")
for n,a,b in [(3,2,1),(4,3,1),(3,5,2)]:
    M=np.full((n,n),float(b)); np.fill_diagonal(M,a)
    print(f"  n={n},a={a},b={b}: det={np.linalg.det(M):.6f}  公式={(a-b)**(n-1)*(a+(n-1)*b)}")

print("\n=== 4 det(I + a aᵀ) = 1 + aᵀa  （这就是 1+a² 那类题）===")
for a in [[1,1,1],[1,2,3],[0.5,2,-1]]:
    av=np.array(a,dtype=float); M=np.eye(len(a))+np.outer(av,av)
    print(f"  a={a}: det={np.linalg.det(M):.6f}   1+aᵀa={1+av@av}")

print("\n=== 5 加边型 D=|1+a1 1 ..; 1 1+a2 ..|  = Πai·(1+Σ1/ai) ===")
def D_add(as_):
    n=len(as_); M=np.ones((n,n))
    for i in range(n): M[i,i]=1+as_[i]
    return np.linalg.det(M)
for as_ in [[1,1,1],[2,3,5],[1,2,3,4]]:
    prod=np.prod(as_); s=prod*(1+sum(1/x for x in as_))
    print(f"  a={as_}: det={D_add(as_):.6f}  公式={s:.6f}")

print("\n=== 6 三对角参数型 |a 1 0;1 a 1;0 1 a| ===")
for a in [2,3]:
    M=np.array([[a,1,0],[1,a,1],[0,1,a]],dtype=float)
    print(f"  a={a}: det={np.linalg.det(M):.6f}   a³-2a={a**3-2*a}")

print("\n=== 7 爪型(箭形)行列式 ===")
M=np.array([[2,1,1,1],[3,2,0,0],[3,0,2,0],[3,0,0,2]],dtype=float)
print("  det=\n",np.linalg.det(M),"  = 2²·(2-3/2-3/2-3/2)=",4*(2-1.5*3))

print("\n=== 8 |A| = Π 特征值 (用特征值求行列式) ===")
A=np.array([[3,1,0],[1,3,1],[0,1,3]],dtype=float)
print("  det=",np.linalg.det(A),"  Πλ=",np.prod(np.linalg.eigvals(A)))
