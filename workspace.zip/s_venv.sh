R=/root/autodl-tmp/_V.txt
rm -f $R
echo "=== venv_lfm2 内容 ===" >> $R
ls /root/venv_lfm2/lib/python3.12/site-packages/ 2>/dev/null | grep -iE "^torch|^transformers|peft|sympy" | head -8 >> $R
echo "=== venv_lfm2 python 能用吗 ===" >> $R
/root/venv_lfm2/bin/python -c "import torch,transformers;print('torch',torch.__version__,'tf',transformers.__version__,'cuda',torch.cuda.is_available())" >> $R 2>&1
echo "=== 能否加载 Qwen2 ===" >> $R
/root/venv_lfm2/bin/python -c "
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
tok=AutoTokenizer.from_pretrained('/root/distill_calc_v1')
md=AutoModelForCausalLM.from_pretrained('/root/distill_calc_v1',dtype=torch.float32)
print('OK 层数',len(md.model.layers),'vocab',md.config.vocab_size)
" >> $R 2>&1
echo "V_DONE" >> $R
