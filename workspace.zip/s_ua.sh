R=/root/autodl-tmp/_UA.txt
rm -f $R
echo "===== align2 目录 =====" >> $R
ls -la /root/autodl-tmp/align2/ 2>/dev/null >> $R
ls -la /workspace/align2/ 2>/dev/null >> $R
echo "" >> $R
echo "===== 所有 unlock/reject 文件 =====" >> $R
find / -maxdepth 5 -iname "*unlock*" -o -maxdepth 5 -iname "*reject*" 2>/dev/null | head -20 >> $R
echo "" >> $R
echo "===== 所有 d_*.bin 方向向量 =====" >> $R
find / -maxdepth 5 -name "d_*.bin" 2>/dev/null | head -20 >> $R
echo "" >> $R
echo "===== 0.5B unlock 脚本 =====" >> $R
grep -rln "d_reject\|qwen_unlocked\|output.bias" /root/*.py /workspace/*.py 2>/dev/null | head -10 >> $R
echo "UA_DONE" >> $R
