echo "=== llama_cpp python 包 ==="
/root/miniconda3/bin/python -c "import llama_cpp; print('OK', llama_cpp.__version__)" 2>&1 | head -2
echo "=== llama-cli 交互相关参数 ==="
/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli --help 2>&1 | grep -iE "cnv|conversation|simple-io|display-prompt|^\-i|interactive" | head -12
