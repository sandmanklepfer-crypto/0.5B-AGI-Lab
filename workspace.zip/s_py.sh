echo "=== 找 python ==="
ls /root/miniconda3/bin/python* /usr/bin/python* 2>/dev/null | head
echo "=== conda envs ==="
ls /root/miniconda3/envs/ 2>/dev/null
echo "=== 历史文件 ==="
ls -la /root/.bash_history 2>/dev/null; history 2>/dev/null | tail -5
