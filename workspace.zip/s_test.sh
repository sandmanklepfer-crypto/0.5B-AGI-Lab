cd /root/autodl-tmp
EXE=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
M=/root/autodl-tmp/qwen05b_q4km.gguf
P="<|im_start|>user\n什么是人工智能？<|im_end|>\n<|im_start|>assistant\n"
echo "############ A. 基线 (无 control vector) ############"
$EXE -m $M -p "$P" -n 60 --temp 0.8 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tail -8
echo ""
echo "############ B. 挂 control vector (scale 0.8, layer 0-23) ############"
$EXE -m $M -p "$P" -n 60 --temp 0.8 -ngl 99 --no-warmup -st --simple-io \
  --control-vector-scaled /root/autodl-tmp/control_struct.gguf:0.8 \
  --control-vector-layer-range 0 23 2>/dev/null | tail -8
echo ""
echo "############ C. 挂 control vector (scale 1.5, layer 10-23) ############"
$EXE -m $M -p "$P" -n 60 --temp 0.8 -ngl 99 --no-warmup -st --simple-io \
  --control-vector-scaled /root/autodl-tmp/control_struct.gguf:1.5 \
  --control-vector-layer-range 10 23 2>/dev/null | tail -8
