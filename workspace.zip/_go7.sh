#!/bin/bash
cd /root/autodl-tmp/life1
nohup /root/miniconda3/bin/python3 -u _up.py > up_run.log 2>&1 &
echo PID=$!
