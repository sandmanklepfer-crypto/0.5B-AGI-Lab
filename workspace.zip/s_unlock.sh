R=/root/autodl-tmp/_UN.txt
rm -f $R
echo "########## build_unlock_3b.py ##########" >> $R
cat /root/autodl-tmp/build_unlock_3b.py >> $R 2>&1
echo "UN_DONE" >> $R
