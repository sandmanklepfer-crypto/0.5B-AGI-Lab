echo "=== 服务器 engine.js 的 chat 注入 ==="
grep -n "step(" /root/autodl-tmp/super_socket/engine.js | head -10
echo "---"
grep -n "eta\|inject\|Inject" /root/autodl-tmp/super_socket/engine.js | head -25
