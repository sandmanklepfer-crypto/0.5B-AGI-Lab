echo "=== cvector 二进制真实位置 ==="
find /root/autodl-tmp/llama.cpp -name "*cvector*" -type f -executable 2>/dev/null | head
find /root/autodl-tmp -name "llama-cvector*" -type f 2>/dev/null | head
ls -la /root/autodl-tmp/llama.cpp/build-cuda/bin/ 2>/dev/null | head -20
ls -la /root/autodl-tmp/llama.cpp/build/bin/ 2>/dev/null | head -20
