cd /root/autodl-tmp
R=/root/autodl-tmp/_w.txt
rm -f $R
echo "##### 所有模型目录 #####" >> $R
du -sh /root/autodl-tmp/*/ 2>/dev/null | sort -rh | head -25 >> $R
echo "" >> $R
echo "##### 含 config.json 的模型目录 #####" >> $R
find /root -maxdepth 4 -name "config.json" 2>/dev/null | head -20 >> $R
echo "" >> $R
echo "##### LLaDA #####" >> $R
ls -la /root/autodl-tmp/llada_try_LLaDA-1B-1B-Instruct/ 2>/dev/null | head >> $R
echo "" >> $R
echo "##### distill_train.log 内容 #####" >> $R
head -20 /root/autodl-tmp/distill_train.log 2>/dev/null >> $R
echo "" >> $R
echo "##### v71_best_chat.py 用什么模型 #####" >> $R
head -25 /root/autodl-tmp/v71_best_chat.py 2>/dev/null >> $R
echo "W_DONE" >> $R
