#!/bin/bash
export ADB=/usr/bin/adb
$ADB start-server >/dev/null 2>&1
dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
[ -z "$dev" ] && { $ADB connect 127.0.0.1:5555 >/dev/null 2>&1; sleep 1; dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}'); }
[ -z "$dev" ] && { echo "NO_DEVICE"; exit 1; }
S(){ timeout 25 $ADB -s "$dev" shell "$@"; }
echo "########## DEVICE: $dev"
echo "===== [1] 僵死进程的父进程是谁 ====="
S 'ps -A -o PID,PPID,USER,ARGS 2>/dev/null | grep -E "^\s*(22881|25111|25153|25154|25167)\b"'
echo "===== [2] 谁持有悬浮窗 (可覆盖界面骗点击) ====="
S 'appops query-op SYSTEM_ALERT_WINDOW allow 2>/dev/null | head -40'
echo "===== [3] 谁有安装其他应用的权限 ====="
S 'appops query-op REQUEST_INSTALL_PACKAGES allow 2>/dev/null | head -30'
echo "===== [4] 用户自建/hook 相关包 ====="
S 'pm list packages | grep -Ei "zhz|life|alarmhook|hook|inject|xposed|frida|lspatch"'
echo "===== [5] com.zhz.alarmhook 详情 ====="
S 'dumpsys package com.zhz.alarmhook 2>/dev/null | grep -Ei "versionName|firstInstallTime|lastUpdateTime|codePath|REQUEST_INSTALL|SCHEDULE_EXACT|RECEIVE_BOOT" | head -15'
echo "===== [6] 开机自启可疑项 (BOOT_COMPLETED 监听者抽样) ====="
S 'cmd package query-services --brief -a android.intent.action.BOOT_COMPLETED 2>/dev/null | head -20'
echo "===== [7] 当前前台/顶层窗口 ====="
S 'dumpsys window 2>/dev/null | grep -E "mCurrentFocus|mFocusedApp"'
echo "===== [8] shell2000d 是什么 ====="
S 'ls -la /data/local/tmp/shell2000d*; file /data/local/tmp/shell2000d 2>/dev/null; head -c 200 /data/local/tmp/shell2000d 2>/dev/null | strings | head -5'
echo "===== [9] turbo.sh 内容 ====="
S 'cat /data/local/tmp/turbo.sh 2>/dev/null | head -40'
