#!/bin/bash
# adb_auto.sh — 自动找到手机无线调试端口 → 连接 → 固化到 5555(持久)
# 用法: bash adb_auto.sh            # 自动扫描连接
#       bash adb_auto.sh <ip:port> <code>   # 指定配对
export ADB=/usr/bin/adb
HOSTS="10.60.79.2 10.105.5.52 127.0.0.1"

$ADB start-server >/dev/null 2>&1

# 若已连上, 直接固化
dev=$($ADB devices 2>/dev/null | awk 'NR>1 && $2=="device"{print $1; exit}')
if [ -n "$dev" ]; then
  echo "[已连接] $dev → 固化到 5555"
  $ADB -s "$dev" tcpip 5555 >/dev/null 2>&1
  ip=$(echo "$dev" | cut -d: -f1)
  sleep 2; $ADB connect "$ip:5555" >/dev/null 2>&1
  $ADB devices | tail -2; exit 0
fi

# 指定配对
if [ -n "$1" ]; then
  $ADB pair "$1" "$2" 2>&1 | head -2
  ip=$(echo "$1" | cut -d: -f1)
  $ADB connect "$ip:5555" >/dev/null 2>&1
  $ADB devices | tail -3; exit 0
fi

echo "[扫描] 自动找 adbd 端口..."
python3 - "$HOSTS" <<'PY'
import socket, sys, concurrent.futures as cf
hosts=sys.argv[1].split()
def probe(hp):
    h,p=hp
    s=socket.socket(); s.settimeout(0.12)
    try: s.connect((h,p)); return (h,p)
    except Exception: return None
    finally:
        try: s.close()
        except: pass
ps=list(range(30000,50100))+list(range(5000,6000))+[5555,5037,7777,8888]
jobs=[(h,p) for p in ps for h in hosts]
res=[]
with cf.ThreadPoolExecutor(max_workers=1200) as ex:
    for r in ex.map(probe, jobs):
        if r: res.append(r); print("FOUND %s:%d"%r, flush=True)
print("DONE", res)
PY
