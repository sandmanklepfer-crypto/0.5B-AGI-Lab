cd /root/autodl-tmp
E=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
Q=/root/autodl-tmp/qwen05b_q4km.gguf
F16=/root/autodl-tmp/qwen05b_fp16.gguf
R=/root/autodl-tmp/_diag.txt
rm -f $R

echo "########## 测试1: 纯续写 (无chat格式), Q4KM ##########" >> $R
timeout 100 $E -m $Q -p "人工智能是计算机科学的一个分支，" -n 40 --temp 0.8 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -8 >> $R

echo "" >> $R
echo "########## 测试2: 纯续写, FP16 ##########" >> $R
timeout 150 $E -m $F16 -p "人工智能是计算机科学的一个分支，" -n 40 --temp 0.8 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -8 >> $R

echo "" >> $R
echo "########## 测试3: 极简续写 Q4KM ##########" >> $R
timeout 100 $E -m $Q -p "今天天气很好，" -n 30 --temp 0.8 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -6 >> $R

echo "" >> $R
echo "########## 测试4: 英文续写 Q4KM ##########" >> $R
timeout 100 $E -m $Q -p "The capital of France is" -n 20 --temp 0.3 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -5 >> $R

echo "DIAG_DONE" >> $R
