# -*- coding: utf-8 -*-
import numpy as np
np.set_printoptions(precision=4, suppress=True)
A=lambda *a: np.array(a, dtype=float)

print("=== 行列式 ===")
print(" |1 2;3 4| =", np.linalg.det(A([1,2],[3,4])))
D=A([1,2,3,4],[2,3,4,1],[3,4,1,2],[4,1,2,3])
print(" 4阶轮换行列式 =", np.linalg.det(D), "(每行和=10, 经典题)")
print(" |2 -1 0;-1 2 -1;0 -1 2| =", np.linalg.det(A([2,-1,0],[-1,2,-1],[0,-1,2])))
print(" |2 0 0;0 3 0;0 0 5| =", np.linalg.det(A([2,0,0],[0,3,0],[0,0,5])))

print("\n=== |kA| 与 |A^{-1}| ===")
M=A([1,2],[3,4]); 
print(" A=[[1,2],[3,4]], |A| =", np.linalg.det(M), ", |2A| =", np.linalg.det(2*M), "= 2^2|A|")
print(" |A^{-1}| =", np.linalg.det(np.linalg.inv(M)), "= 1/|A|")

print("\n=== 逆矩阵（伴随法验算）===")
B=A([1,2,3],[2,2,1],[3,4,3])
print(" B=\n",B,"\n |B| =", np.linalg.det(B))
print(" B^{-1} =\n", np.linalg.inv(B))
print(" B·B^{-1} =\n", np.round(B@np.linalg.inv(B),10))

print("\n=== 解方程组 ===")
C=A([1,1,1],[1,2,3],[1,3,6]); b=A([3,6,10])
print(" |C| =", np.linalg.det(C), " 解 x =", np.linalg.solve(C,b))
print(" 验证 Cx-b =", np.round(C@np.linalg.solve(C,b)-b,10))

print("\n=== 含参数方程组（讨论）===")
# x1+x2+ x3=1; x1+2x2+3x3=1; x1+4x2+ax3=1
for a in [5, 9]:
    Dm=A([1,1,1],[1,2,3],[1,4,a])
    print(f" a={a}: det={np.linalg.det(Dm):.4f}", "无唯一解" if abs(np.linalg.det(Dm))<1e-9 else "唯一解")

print("\n=== 秩 ===")
R=A([1,2,-1,3],[2,1,1,2],[3,3,0,5])
print(" r =", np.linalg.matrix_rank(R))
R2=A([1,2,3],[2,4,6],[1,0,1])
print(" [[1,2,3],[2,4,6],[1,0,1]] 的秩 =", np.linalg.matrix_rank(R2), "(第2行=2×第1行)")

print("\n=== 特征值/特征向量 ===")
S=A([2,1],[1,2])
w,v=np.linalg.eig(S)
print(" A=[[2,1],[1,2]]: 特征值 =", w, " 特征向量 =\n", v)
S2=A([1,2],[2,1]); w2,v2=np.linalg.eig(S2)
print(" A=[[1,2],[2,1]]: 特征值 =", w2, " 特征向量 =\n", v2)

print("\n=== 相似对角化 A=[[2,1],[1,2]] ===")
P=A([1,1],[1,-1])
print(" P=\n",P,"\n P^{-1}AP =\n", np.round(np.linalg.inv(P)@S@P,10))

print("\n=== 二次型配方法 ===")
Q=A([1,1,0],[1,1,0],[0,0,1])
print(" 二次型矩阵特征值 =", np.linalg.eigvalsh(Q))
