#!/bin/bash
# adbq.sh — 只做“确保有设备可用”这一件事
export ADB=/usr/bin/adb
$ADB start-server >/dev/null 2>&1
dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
if [ -z "$dev" ]; then
  $ADB connect 127.0.0.1:5555 >/dev/null 2>&1
  $ADB -s emulator-5554 reconnect >/dev/null 2>&1
  sleep 1
  dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
fi
[ -z "$dev" ] && { echo "NO_DEVICE"; exit 1; }
echo "$dev"
