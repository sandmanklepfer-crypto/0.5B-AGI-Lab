cd /root/autodl-tmp
R=/root/autodl-tmp/_EXT.txt
rm -f $R
for a in 5 20 50; do
  echo "=== extend alpha=$a ===" >> $R
  /root/miniconda3/bin/python tools/extend_gguf.py \
    /root/autodl-tmp/calc_v1.gguf \
    /root/autodl-tmp/calc_v1_un${a}.gguf \
    output.bias /root/autodl-tmp/bias_a${a}.bin f32 >> $R 2>&1
  echo "rc=$?" >> $R
  ls -la /root/autodl-tmp/calc_v1_un${a}.gguf >> $R 2>&1
done
echo "EXT_DONE" >> $R
