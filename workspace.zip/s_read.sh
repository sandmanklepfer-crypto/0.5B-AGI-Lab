cd /root/autodl-tmp
for t in base1 base2 cvec1 cvec2 neg1 s03; do
  echo "########## $t ##########"
  cat _o_$t.txt 2>/dev/null | tr -d '\r' | grep -v "^$" | tail -3
  echo ""
done
