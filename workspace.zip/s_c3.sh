R=/root/autodl-tmp/_C3.txt
rm -f $R
echo "===== infer_with_calc (完整闭环) =====" >> $R
sed -n '68,140p' /root/calc_token.py >> $R 2>&1
echo "C3_DONE" >> $R
