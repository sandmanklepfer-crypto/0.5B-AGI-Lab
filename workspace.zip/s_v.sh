cd /root/autodl-tmp
E=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
Q=/root/autodl-tmp/qwen05b_q4km.gguf
R=/root/autodl-tmp/_v.txt
rm -f $R
echo "##### 纯续写格式问数学 #####" >> $R
timeout 90 $E -m $Q -p "数学题：12加34等于多少？答案：" -n 25 --temp 0.3 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -5 >> $R
echo "" >> $R
echo "##### 纯续写问知识 #####" >> $R
timeout 90 $E -m $Q -p "水的沸点是" -n 20 --temp 0.3 -ngl 99 --no-warmup -st --simple-io 2>/dev/null | tr -d '\r' | tail -4 >> $R
echo "" >> $R
echo "##### 找 instruct 模型 #####" >> $R
ls -la /root/autodl-tmp/*instruct* /root/autodl-tmp/*chat* /root/autodl-tmp/*distill* /root/autodl-tmp/*king* 2>/dev/null >> $R
ls /root/autodl-tmp/ | grep -iE "instruct|chat|distill|king|ft_" >> $R
echo "V_DONE" >> $R
