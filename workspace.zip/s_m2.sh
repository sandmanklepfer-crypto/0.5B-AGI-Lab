cd /root/autodl-tmp
E=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
M=/root/autodl-tmp/qwen05b_q4km.gguf
CVF=/root/autodl-tmp/control_struct.gguf
F=/root/autodl-tmp/_multi.txt
rm -f $F
q(){ printf '<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n' "$1"; }
one(){ # tag prompt usecvec
  tag=$1; p=$2; use=$3
  echo "===== [$tag] $p =====" >> $F
  if [ "$use" = "yes" ]; then
    $E -m $M -p "$(q "$p")" -n 40 --temp 0.7 -ngl 99 --no-warmup -st --simple-io \
       --control-vector-scaled $CVF:0.8 --control-vector-layer-range 0 23 2>/dev/null \
       | tr -d '\r' | grep -vE "^$|Prompt:|Exiting|Loading|^ *$|^ *$" | head -2 >> $F
  else
    $E -m $M -p "$(q "$p")" -n 40 --temp 0.7 -ngl 99 --no-warmup -st --simple-io 2>/dev/null \
       | tr -d '\r' | grep -vE "^$|Prompt:|Exiting|Loading|^ *$|^ *$" | head -2 >> $F
  fi
}
one "P1-base" "1+2+3+4+5等于多少？" no
one "P1-cvec" "1+2+3+4+5等于多少？" yes
one "P2-base" "解释一下水循环。" no
one "P2-cvec" "解释一下水循环。" yes
one "P3-base" "为什么天是蓝色的？" no
one "P3-cvec" "为什么天是蓝色的？" yes
one "P4-base" "介绍一下你自己。" no
one "P4-cvec" "介绍一下你自己。" yes
echo "M2 DONE" >> $F
