cd /root/autodl-tmp
nohup /root/autodl-tmp/llama.cpp/build-cuda/bin/llama-server \
  -m /root/autodl-tmp/calc_v1_un5.gguf --port 8090 -ngl 99 -c 1024 --host 127.0.0.1 \
  > /root/autodl-tmp/_srv_un5.log 2>&1 &
echo pid=$!
sleep 30
tail -3 /root/autodl-tmp/_srv_un5.log
