#!/bin/bash
# rbg.sh "<cmd>" [tag]  — 远程后台执行, 立刻返回
TAG=${2:-job}
bash /workspace/.ssh/rsh "nohup bash -c '$1' > /root/autodl-tmp/_${TAG}.log 2>&1 & echo PID=\$! >> /root/autodl-tmp/_${TAG}.log" 2>&1 | tail -1
