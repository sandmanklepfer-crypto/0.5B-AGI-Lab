echo "=== llama.cpp 位置 ==="
ls -d /root/autodl-tmp/*llama* /root/autodl-tmp/lcpp /root/lcpp 2>/dev/null
find /root -maxdepth 3 -name 'llama.h' 2>/dev/null | head -5
echo "=== 已有二进制 ==="
find /root -maxdepth 5 \( -name 'llama-cli' -o -name 'cvector-generator' -o -name 'libllama.so' \) 2>/dev/null | head -10
echo "=== life_engine 相关目录 ==="
ls /root/autodl-tmp/ | grep -iE "life|engine|apk|build|src" | head -20
echo "=== NDK ==="
ls -d /root/autodl-tmp/android-ndk-r26d/toolchains/llvm/prebuilt/*/bin 2>/dev/null
