R=/root/autodl-tmp/_CL.txt
rm -f $R
echo "===== calc_token.py (训练脚本) =====" >> $R
head -70 /root/calc_token.py 2>/dev/null >> $R
echo "" >> $R
echo "===== 找 calc 外部计算器 =====" >> $R
grep -rln "calc⟩\|⟨calc\|<calc>\|CALC" /root/*.py /root/autodl-tmp/*.py 2>/dev/null | head -10 >> $R
echo "" >> $R
echo "===== 测试: 完整流程 (模型出表达式+外部算) =====" >> $R
echo "CL_DONE" >> $R
