#!/bin/bash
cd /root/autodl-tmp/life1
nohup /root/miniconda3/bin/python3 -u _bridge.py > b1.log 2>&1 &
echo $! > b1.pid
