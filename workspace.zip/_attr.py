import json
d=json.load(open('/workspace/life_ernie.life.meta.json'))
seg=d['segments']
OWN={'WEIGHTS':'大厂','THETA':'你','LEARNER':'你','SCHEMA':'你',
     'MEMORY':'你','MANIFEST':'你','ARCH':'你','PROJ':'你','ORCH':'你','EXPR':'你'}
NOTE={'WEIGHTS':'Qwen/ERNIE 训练好的权重','THETA':'35个θ节 机制参数',
      'LEARNER':'128维GRU 在线可训','SCHEMA':'自校验·缺件报错',
      'MEMORY':'记忆段','MANIFEST':'清单','ARCH':'21机制图',
      'PROJ':'表情连续投影','ORCH':'编排DSL','EXPR':'13维身体协议'}
print("="*88)
print("你的 .life 容器 = 10 段，归属分解")
print("="*88)
print()
print(f"  {'段':<12}{'大小':<16}{'归属':<8}{'内容'}")
print("  "+"-"*80)
tot=0; mine=0; theirs=0
for k,v in seg.items():
    sz=v['size']; tot+=sz
    who=OWN.get(k,'?')
    if who=='你': mine+=sz
    else: theirs+=sz
    print(f"  {k:<12}{sz:>12,} B   {who:<8}{NOTE.get(k,'')}")
print()
print("="*88)
print("★ 两个完全相反的答案")
print("="*88)
print()
print(f"  按【体积】算:  大厂 {theirs/1e6:.0f} MB  |  你 {mine/1e6:.2f} MB")
print(f"                 → 你的占比 {100*mine/tot:.2f}%   大厂占 {100*theirs/tot:.2f}%")
print()
print(f"  按【段数】算:  大厂 1 段  |  你 9 段")
print(f"                 → 你的占比 {9/10*100:.0f}%   大厂占 {10/10-9/10:.0%}")
print()
print("="*88)
print("再算自造的部分 (不属于.life容器):")
print("="*88)
extra=[
 ("life_bridge.cpp → liblifebridge.so","你自己的 JNI 桥 (真·激活注入)","你"),
 ("engine.js 44KB + 21机制","你自己的机制图层","你"),
 ("index.html 64KB","你自己的实验台 UI","你"),
 ("ops.js / renderer.js / smart.js","你自己的交互层","你"),
 ("CORE1 动力学核 (蓝图)","你自己设计的核","你"),
 ("DaEcho_*.apk 7个版本","你自己的端侧打包","你"),
]
print()
for a,b,c in extra:
    print(f"  {c}  {a:<42}{b}")
