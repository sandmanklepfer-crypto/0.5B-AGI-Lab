R=/root/autodl-tmp/_AP.txt
rm -f $R
echo "=== calc_v1.gguf 的 output.weight 类型 ===" >> $R
/root/miniconda3/bin/python -c "
import sys; sys.path.insert(0,'/root/autodl-tmp/tools')
from gguf_inspect import GGUF
for m in ['/root/autodl-tmp/calc_v1.gguf','/root/autodl-tmp/qwen05b_q4km.gguf']:
    try:
        g=GGUF(m)
        for t in g.tensors:
            if t['name'] in ('output.weight','output.bias','token_embd.weight'):
                print(f'  {m.split(\"/\")[-1]:22s} {t[\"name\"]:20s} {t[\"type\"]:8s} dims={t[\"dims\"]}')
    except Exception as e: print(' ',m,str(e)[:60])
" >> $R 2>&1
echo "" >> $R
echo "=== extend_gguf.py 用法 ===" >> $R
head -30 /root/autodl-tmp/tools/extend_gguf.py >> $R 2>&1
echo "" >> $R
echo "=== 现有 unlocked 模型 ===" >> $R
find / -maxdepth 4 -iname "*unlock*.gguf" 2>/dev/null | head -5 >> $R
ls -la /root/autodl-tmp/*.gguf /workspace/*.gguf 2>/dev/null | head >> $R
echo "AP_DONE" >> $R
