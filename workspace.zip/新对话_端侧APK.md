# 新对话交接: 端侧 APK —— 【已完成 v2.0】通用实验台

## 状态: ✅ 已交付
- 产物: `/workspace/life_apk/活体实验台_v2.0.apk` (403.8 MB, 签名通过)
- 详见: `/workspace/端侧实验台_完成交接.md` (完整技术交接)

## 一句话
带 **0.5B 真实权重** + **22 个机制全量** + **通用实验台(人机双通道全开放, 含权重级)** 的真 APK 已打出, JS 引擎 22 机制零异常跑通。

## 三通道"完全自定义"
1. **人类**: 机制图节点(长按改源码热重载) + θ 全参数滑块 + 编排 DSL + 权重层(列/读/写张量, 挂卸 LoRA)
2. **权重级开放**: `llama_model_get_tensor_ptr` → 列/读(dequant)/写(F32·F16/LoRA)
3. **AI 自改**: `selfModify(自然语言→θ/图操作)` + 元盒自发自改(连续动力学, 非裁判)

## 构建链(可复现)
```
① 模型:  qwen25_base_raw → convert_hf_to_gguf.py → f16 → llama-quantize Q4_K_M (379MB)
② NDK:    android-ndk-r26d → cmake 交叉编译 llama.cpp(arm64-v8a) → 5 个 .so
          (补丁: src/llama-mmap.cpp 的 POSIX_MADV_*/posix_madvise → madvise)
③ .life:  pack_life.py (10 段: 权重/θ/learner/schema/记忆/清单/架构图/投影/编排/表情)
④ JNI:    life_bridge.cpp (输入层 embd 注入 + 权重层 ops)
⑤ 打包:   build.sh (javac→patch→dx→aapt2→注入dex/so/.life→zipalign→apksigner)
```

## 服务器
- SSH: `connect.nma1.seetacloud.com:25914` root / `G#7vL，qR!zWp@3`
- `/root/autodl-tmp/life_engine.life` (382MB, 已生成)
- `/root/autodl-tmp/llama.cpp/build-android/` (arm64 交叉编译产物)
- `/root/autodl-tmp/libout/` (5 个 strip 后 .so)
- `/root/autodl-tmp/super_socket/pack_life.py` (打包器)
- 辅助脚本: `/workspace/.ssh/rsh` (远程 shell), `/workspace/.ssh/rcp`

## 本地
- `/workspace/life_engine/` — engine.js, index.html, life_bridge.cpp, test_engine.js
- `/workspace/life_apk/` — src/, libs/arm64-v8a/, assets/, build.sh, 活体实验台_v2.0.apk
- `/workspace/super_socket/` — pack_life.py, master_params.json, super_socket_std.py
- 签名: `/workspace/rebuild/modkey.jks` (daecho123 / daecho)

## 下一步(若要继续)
1. 真机测试(native 库 arm64, 本地 x86 无法验证)
2. 逐层注入: 用 `llama_context_params.cb_eval` 替代输入层 embd 注入
3. `selfModifyNL`: 接本地 0.5B 解析自然语言 → 操作序列(通道已留)
4. 量化张量可写: dequant-modify-requant
5. 固化闭环: 端侧 experience → LoRA → 挂载 → 下次命中
6. APK 瘦身: Q4_0 / IQ 系列

## 踩坑(勿重复)
- bionic 无 `posix_madvise`/`POSIX_MADV_*`
- 老 android.jar(API16) 无 `org.json` 桩 → 自带 MiniJSON
- javac release 8 的 class 版本要 patch 到 50 才喂得动老 dx.jar
- WebView↔Java 用 life:// 协议(免 @JavascriptInterface 注解类)
- .life 401MB 必须 `zip -0` stored 入 APK(aapt2 压缩太慢)
- `llama_model_params` 无 `use_mmap` 字段(此版本)
