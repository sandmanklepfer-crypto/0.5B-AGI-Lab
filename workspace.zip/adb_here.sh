#!/bin/bash
# adb_here.sh — 一键连接（本机回环，不需要 WiFi/IP）
# 用法: bash adb_here.sh              → 尝试用 127.0.0.1:5555 重连
#       bash adb_here.sh <port> <码>  → 首次配对（手机上开无线调试后）
export ADB=/usr/bin/adb
$ADB start-server >/dev/null 2>&1

# 已是 5555 模式 → 直接连回环
if timeout 8 $ADB connect 127.0.0.1:5555 2>&1 | grep -q connected; then
  echo "✅ 已连接 127.0.0.1:5555"
  $ADB devices | tail -2
  exit 0
fi

# 首次配对
if [ -n "$1" ]; then
  echo "配对 $1 ..."
  $ADB pair "$1" "$2" 2>&1 | head -2
  ip=$(echo "$1" | cut -d: -f1)
  $ADB connect "$ip:5555" >/dev/null 2>&1
  sleep 1
  # 切换成固定端口
  dev=$($ADB devices | awk 'NR>1 && $2=="device"{print $1; exit}')
  [ -n "$dev" ] && $ADB -s "$dev" tcpip 5555 >/dev/null 2>&1
  sleep 4
  $ADB connect 127.0.0.1:5555 >/dev/null 2>&1
  echo "✅ 已固定到 127.0.0.1:5555"
  $ADB devices | tail -2
  exit 0
fi

# 列出当前无线调试端口（若已知）
echo "❌ 未连接。请："
echo "   1) 手机打开「设置→开发者选项→无线调试」"
echo "   2) 把「IP 地址和端口」+ 配对码发我"
exit 1
