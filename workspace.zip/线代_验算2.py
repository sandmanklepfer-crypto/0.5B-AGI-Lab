# -*- coding: utf-8 -*-
import numpy as np
np.set_printoptions(precision=6, suppress=True)
A=lambda *a: np.array(a, dtype=float)

print("=== 解方程组 Cx=b ===")
C=A([1,1,1],[1,2,3],[1,3,6]); b=np.array([3.,6.,10.])
print(" C=\n",C,"\n |C|=",np.linalg.det(C))
x=np.linalg.solve(C,b); print(" 解 x =",x," 验证 Cx =",np.round(C@x,8))

print("\n=== 含参数方程组 x1+x2+x3=1; x1+2x2+3x3=1; x1+4x2+ax3=1 ===")
for a in [5.0,9.0]:
    Dm=A([1,1,1],[1,2,3],[1,4,a]); d=np.linalg.det(Dm)
    tag="唯一解" if abs(d)>1e-9 else "det=0,需讨论"
    print(f" a={a}: det={d:.6f} -> {tag}")

print("\n=== 秩 ===")
R=A([1,2,-1,3],[2,1,1,2],[3,3,0,5]); print(" r([1,2,-1,3;2,1,1,2;3,3,0,5]) =",np.linalg.matrix_rank(R))
R2=A([1,2,3],[2,4,6],[1,0,1]); print(" r= ",np.linalg.matrix_rank(R2))

print("\n=== 特征值/特征向量 ===")
S=A([2,1],[1,2]); w,v=np.linalg.eig(S)
print(" A=[[2,1],[1,2]] 特征值:",w,"  特征向量(列):\n",v)
print(" 验算 A@(1,1) =", S@np.array([1,1]), "= 3*(1,1)")

print("\n=== 相似对角化 ===")
P=A([1,1],[1,-1]); print(" P=\n",P,"\n P^{-1}AP=\n",np.round(np.linalg.inv(P)@S@P,8))

print("\n=== 二次型 x1²+2x2²+3x3²+2x1x2 (配方法) ===")
Qm=A([1,1,0],[1,2,0],[0,0,3]); print(" 矩阵=\n",Qm,"\n 特征值(正交变换下标准形系数)=",np.linalg.eigvalsh(Qm))

print("\n=== 向量组线性相关性 ===")
V=A([1,2,3],[4,5,6],[7,8,9]); print(" (1,2,3),(4,5,6),(7,8,9) 的秩 =",np.linalg.matrix_rank(V),"<3 ⇒ 线性相关")
w3=np.linalg.eigvals(V); print(" 其特征值:",w3,"(含0 ⇒ 不可逆/相关)")

print("\n=== AB=0 但 A,B≠0 的例子 ===")
A1=A([1,1],[2,2]); B1=A([1,-1],[-1,1])
print(" A=\n",A1,"\n B=\n",B1,"\n AB=\n",A1@B1,"  但 |A|=",np.linalg.det(A1),"|B|=",np.linalg.det(B1))

print("\n=== 经典讨论题 ===")
print(" x1+x2+x3=1; x1+2x2+3x3=1; x1+4x2+k*x3=1")
import numpy as np
for k in [5.0,6.0,7.0,8.0]:
    Dm=A([1,1,1],[1,2,3],[1,4,k]); d=np.linalg.det(Dm)
    if abs(d)>1e-9:
        print(f"  k={k}: det={d:.4f}≠0 → 唯一解 x={np.linalg.solve(Dm,np.array([1.,1.,1.]))}")
    else:
        print(f"  k={k}: det=0 → 秩={np.linalg.matrix_rank(Dm)}, 增广秩={np.linalg.matrix_rank(np.column_stack([Dm,[1,1,1]]))} → 无穷多解")
        # 一般解
        print("      由 x2+2x3=0，x1+x2+x3=1 ⇒ x2=-2c, x1=1+c, x3=c")
