echo "=== antiheb 模型在哪 ==="
find /root -maxdepth 3 -iname "*antiheb*" 2>/dev/null | head -15
echo ""
echo "=== v72_apply_antiheb.py 内容 ==="
head -50 /root/autodl-tmp/v72_apply_antiheb.py 2>/dev/null
echo ""
echo "=== 找 antiheb 的 gguf ==="
find /root -name "*.gguf" 2>/dev/null | head -20
