cd /root/autodl-tmp
E=/root/autodl-tmp/llama.cpp/build-cuda/bin/llama-cli
M=/root/autodl-tmp/qwen05b_q4km.gguf
M3=/root/autodl-tmp/ernie03b.gguf
CVF=/root/autodl-tmp/control_struct.gguf
F=/root/autodl-tmp/_reason.txt
rm -f $F
q(){ printf '<|im_start|>user\n%s<|im_end|>\n<|im_start|>assistant\n' "$1"; }

# 推理任务: 1步-2步-3步算术 + 逻辑
T1="12+34等于多少？只回答数字。"
T2="12+34+56等于多少？只回答数字。"
T3="(12+34)*2等于多少？只回答数字。"
T4="如果A大于B，B大于C，那么A和C谁大？"

one(){ # model tag prompt cvec(0/1) extra
  mdl=$1; tag=$2; p=$3; us=$4
  echo "[$tag]" >> $F
  if [ "$us" = "1" ]; then
    $E -m $mdl -p "$(q "$p")" -n 30 --temp 0.3 -ngl 99 --no-warmup -st --simple-io \
      --control-vector-scaled $CVF:0.8 --control-vector-layer-range 0 23 2>/dev/null \
      | tr -d '\r' | grep -vE "^$|Prompt:|Exiting|Loading" | tr '\n' ' ' | cut -c1-150 >> $F
  else
    $E -m $mdl -p "$(q "$p")" -n 30 --temp 0.3 -ngl 99 --no-warmup -st --simple-io 2>/dev/null \
      | tr -d '\r' | grep -vE "^$|Prompt:|Exiting|Loading" | tr '\n' ' ' | cut -c1-150 >> $F
  fi
  echo "" >> $F
}
for t in "$T1" "$T2" "$T3" "$T4"; do
  one $M    "0.5B 基线  | $t" "$t" 0
  one $M    "0.5B +cvec| $t" "$t" 1
  one $M3   "3B  基线  | $t" "$t" 0
done
echo "REASON DONE" >> $F
