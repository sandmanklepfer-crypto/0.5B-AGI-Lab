cd /root/autodl-tmp
nohup /root/autodl-tmp/llama.cpp/build-cuda/bin/llama-server -m /root/autodl-tmp/un_neg150.gguf --port 8091 -ngl 99 -c 1024 --host 127.0.0.1 > _srv_n1.log 2>&1 &
nohup /root/autodl-tmp/llama.cpp/build-cuda/bin/llama-server -m /root/autodl-tmp/un_pos150.gguf --port 8092 -ngl 99 -c 1024 --host 127.0.0.1 > _srv_p1.log 2>&1 &
sleep 35
for p in 8091 8092; do tail -1 _srv_$( [ $p = 8091 ] && echo n1 || echo p1 ).log; done
